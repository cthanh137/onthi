# 📡 MyRenderRat - Hướng Dẫn Sử Dụng Toàn Bộ

## 📋 Giới Thiệu

**MyRenderRat** là hệ thống kiểm soát máy tính từ xa (Remote Access Tool) cho phép bạn:
- 📸 Chụp màn hình từ xa
- 🎬 Stream video real-time
- ⚙️ Quản lý tiến trình
- 📁 Quản lý tập tin
- 💻 Thực thi lệnh hệ thống
- 🔐 Xác thực qua web interface

## 🏗️ Cấu Trúc Dự Án

```
MyRenderRat/
├── server.py              # Server FastAPI + WebSocket (chạy trên máy quản lý)
├── client.py              # Client kết nối (chạy trên máy được kiểm soát)
├── auth.json              # Danh sách tài khoản
├── sessions.json          # Quản lý phiên đăng nhập
├── requirements-server.txt # Thư viện server
├── requirements-client.txt # Thư viện client
├── templates/
│   ├── login.html         # Trang đăng nhập
│   └── admin.html         # Bảng điều khiển
└── static/                # Tập tin tĩnh (CSS, JS)
```

---

## 🚀 Cài Đặt & Chạy

### A. PHÍA SERVER (Máy Quản Lý)

#### 1. Cài Đặt Python & Dependencies
```bash
# Cài Python 3.8+
python --version  # Kiểm tra

# Cài thư viện
pip install -r requirements-server.txt
```

#### 2. Tùy Chỉnh Cấu Hình
Chỉnh sửa `server.py`:
```python
SERVER_NAME = "MyRenderRat v1.0"  # Tên server
SERVER_PORT = 8000                 # Cổng (mặc định 8000)
SESSION_TIMEOUT = 1800             # Timeout phiên (giây)
```

#### 3. Sửa Tài Khoản Trong `auth.json`
```json
{
  "users": [
    {
      "username": "admin",
      "password": "Your_Secure_Password_123"
    },
    {
      "username": "operator",
      "password": "Another_Secure_Pass_456"
    }
  ]
}
```

#### 4. Chạy Server
```bash
python server.py
```

**Output:**
```
============================================================
  MyRenderRat v1.0 đã khởi động!
============================================================
  Trang quản lý: http://localhost:8000
  Đăng nhập: http://localhost:8000/login
  WebSocket Admin: ws://localhost:8000/ws/admin
  WebSocket Client: ws://localhost:8000/ws/client/{id}
============================================================
```

#### 5. Truy Cập Web Interface
Mở browser → `http://localhost:8000/login`
- Username: `admin`
- Password: `MySecurePass@123` (hoặc mật khẩu bạn đặt)

---

### B. PHÍA CLIENT (Máy Được Kiểm Soát)

#### 1. Cài Đặt Dependencies
```bash
pip install -r requirements-client.txt
```

#### 2. Cấu Hình Client
Chỉnh sửa `client.py`:
```python
# Thay đổi URL server để phù hợp với IP/domain của server
SERVER_URL = "ws://192.168.1.100:8000"  # IP của server
# Hoặc nếu server trên internet:
SERVER_URL = "ws://your-domain.com:8000"

CLIENT_ID = str(uuid.uuid4())[:12]  # Sẽ tự sinh
```

#### 3. Chạy Client
```bash
python client.py
```

**Output:**
```
============================================================
  MyRenderRat Client v1.0
============================================================
  Client ID: a1b2c3d4e5f6
  Server: ws://192.168.1.100:8000
  OS: Windows 10
============================================================
[CLIENT] Đang kết nối tới ws://192.168.1.100:8000/ws/client/a1b2c3d4e5f6...
[CLIENT] Đã kết nối thành công!
```

---

## 💻 Sử Dụng Web Interface

### 1. Đăng Nhập
- URL: `http://localhost:8000/login`
- Nhập username & password từ `auth.json`

### 2. Bảng Điều Khiển Chính
Sau khi đăng nhập, bạn sẽ thấy:
- **Danh sách Client**: Hiển thị tất cả client đang kết nối
- **Điều khiển**: Nút chụp screenshot, stream video, v.v.

### 3. Các Tính Năng
```
1. SCREENSHOT
   - Chụp toàn bộ màn hình của client
   - Tùy chỉnh chất lượng (50-95%)

2. VIDEO STREAM
   - Stream real-time màn hình
   - FPS ~20 (tùy thuộc network)

3. COMMAND EXECUTION
   - Thực thi lệnh shell/cmd
   - Xem output trực tiếp

4. SYSTEM INFO
   - CPU, RAM, Disk
   - Thông tin hệ điều hành

5. PROCESS MANAGER
   - Danh sách tất cả tiến trình
   - Kết thúc tiến trình

6. FILE MANAGER
   - Duyệt thư mục
   - Tải file từ client
   - Đọc nội dung tập tin

7. CLIPBOARD
   - Đọc/ghi clipboard

8. AUDIO PLAYBACK
   - Phát âm thanh trên client
```

---

## 📊 Mô Phỏng Kiến Trúc

```
┌─────────────────────────────┐
│   Admin Web Browser         │
│  (http://localhost:8000)    │
└──────────────┬──────────────┘
               │ HTTP/WebSocket
               │
┌──────────────▼──────────────┐
│   FastAPI Server            │
│   (server.py)               │
│  - Quản lý client           │
│  - Xác thực người dùng      │
│  - Relay messages           │
└──────────────┬──────────────┘
               │ WebSocket
               │
┌──────────────▼──────────────┐
│   Client Application        │
│   (client.py)               │
│  - Chụp screenshot          │
│  - Stream video             │
│  - Thực thi lệnh            │
│  - Quản lý file             │
└─────────────────────────────┘
```

---

## 🔐 Bảo Mật

### 1. Thay Đổi Mật Khẩu Mặc Định
**Bắt buộc** khi deploy lên production:
```json
{
  "users": [
    {
      "username": "admin",
      "password": "VeryComplexPassword@2024#Secure!"
    }
  ]
}
```

### 2. Chạy HTTPS/WSS (Bảo Mật Tuyệt Đối)

#### Tạo Self-Signed Certificate:
```bash
# Linux/Mac
openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365 -nodes

# Windows (dùng Git Bash hoặc WSL)
openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365 -nodes
```

#### Chỉnh sửa `server.py`:
```python
# Thay thế main section:
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        ssl_keyfile="key.pem",
        ssl_certfile="cert.pem"
    )
```

#### Chỉnh sửa `client.py`:
```python
SERVER_URL = "wss://your-domain.com:8000"  # wss thay vì ws
```

### 3. Firewall & Network
```bash
# Chỉ cho phép truy cập từ IP tin cậy
# Ví dụ ufw (Ubuntu):
sudo ufw allow from 192.168.1.0/24 to any port 8000
```

---

## 🐛 Troubleshooting

### Lỗi: "Connection refused"
```
❌ Problem: Client không thể kết nối đến server
✅ Solution:
   1. Kiểm tra server đang chạy: netstat -an | grep 8000
   2. Kiểm tra IP server chính xác: ipconfig (Windows) hoặc ifconfig (Linux)
   3. Kiểm tra firewall: cho phép cổng 8000
   4. Đảm bảo client & server cùng network hoặc server công khai
```

### Lỗi: "Port already in use"
```bash
# Tìm process sử dụng port
lsof -i :8000 (Linux/Mac)
netstat -ano | findstr :8000 (Windows)

# Kill process
kill -9 <PID> (Linux/Mac)
taskkill /PID <PID> /F (Windows)
```

### Screenshot không hoạt động
```
❌ Problem: Client không chụp được screenshot
✅ Solution:
   1. Cài Pillow: pip install pillow
   2. Trên Linux cài: sudo apt install python3-tk python3-dev
   3. Kiểm tra: python -c "from PIL import ImageGrab"
```

### Client ngắt kết nối liên tục
```
❌ Problem: "Connection closed" liên tục
✅ Solution:
   1. Kiểm tra network: ping server
   2. Tăng RECONNECT_INTERVAL: RECONNECT_INTERVAL = 10
   3. Kiểm tra logs server: xem lỗi chi tiết
```

---

## 📈 Mở Rộng & Tùy Chỉnh

### 1. Thêm Tính Năng Mới

**Ví dụ: Lấy IP địa chỉ của client**

Trong `client.py`:
```python
def get_network_info():
    """Lấy thông tin mạng"""
    import socket
    try:
        return {
            "hostname": socket.gethostname(),
            "ip_address": socket.gethostbyname(socket.gethostname())
        }
    except:
        return {}

# Thêm vào handle_connection():
elif msg_type == "request_network_info":
    response = {
        "type": "network_info",
        "data": get_network_info()
    }
```

### 2. Lưu Log

Thêm logging vào `server.py`:
```python
import logging

logging.basicConfig(
    filename='server.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Sử dụng:
logging.info(f"Client {client_id} connected")
```

### 3. Database (Optional)

Thay thế JSON với SQLite/PostgreSQL:
```python
# Cài: pip install sqlalchemy
from sqlalchemy import create_engine
# ... (cấu hình database)
```

---

## 📱 Deploy Lên Internet

### Option 1: VPS (Recommended)
```bash
# 1. Thuê VPS (DigitalOcean, Linode, AWS)
# 2. SSH vào VPS
ssh root@your_vps_ip

# 3. Cài Python & cấu hình
apt update && apt install python3-pip
pip install -r requirements-server.txt

# 4. Chạy server nền (Screen/tmux)
screen -S renderrat
python server.py

# 5. Config domain (DNS)
# Trỏ domain.com → IP_VPS

# 6. Setup HTTPS
# (xem phần "Chạy HTTPS/WSS" ở trên)
```

### Option 2: Render.com (Free Tier)
```
1. Tạo tài khoản: render.com
2. New → Web Service
3. Kết nối GitHub repo
4. Environment: Python 3.9
5. Build: pip install -r requirements-server.txt
6. Start: uvicorn server:app --host 0.0.0.0 --port 10000
```

---

## 📞 Support

Các vấn đề thường gặp:
- 🔴 Client không thấy trong danh sách? → Kiểm tra kết nối WebSocket
- 🔴 Screenshot bị chậm? → Giảm chất lượng (quality=50)
- 🔴 Lệnh timeout? → Tăng timeout trong execute_command()

---

## ⚖️ Tuyên Bố Pháp Lý

⚠️ **CHỈ SỬ DỤNG CHO MỤC ĐÍCH HỢP PHÁP**
- Chỉ kiểm soát máy tính của bạn hoặc có sự đồng ý của chủ sở hữu
- Không sử dụng để theo dõi, gián điệp, hoặc tấn công
- Tác giả không chịu trách nhiệm cho việc lạm dụng

---

**Version**: 1.0  
**Last Updated**: April 2025  
**Author**: Your Name  
**License**: MIT (tùy chọn)

Good luck! 🚀
