# MyRenderRat Installation & Setup Guide

## 📋 Table of Contents
1. [System Requirements](#system-requirements)
2. [Installation](#installation)
3. [Configuration](#configuration)
4. [Running Server](#running-server)
5. [Running Client](#running-client)
6. [Web Interface](#web-interface)
7. [Troubleshooting](#troubleshooting)

---

## System Requirements

### Server Requirements
- **Python**: 3.8 or higher
- **OS**: Windows, Linux, or macOS
- **RAM**: 512 MB minimum
- **Network**: Outbound TCP/WebSocket support
- **Dependencies**: Listed in `requirements-server.txt`

### Client Requirements
- **Python**: 3.8 or higher
- **OS**: Windows (recommended), Linux, or macOS
- **RAM**: 256 MB minimum
- **Disk Space**: ~50 MB (with Python environment)
- **Dependencies**: Listed in `requirements-client.txt`

---

## Installation

### Step 1: Install Python Dependencies

**For Server:**
```bash
pip install -r requirements-server.txt
```

**For Client:**
```bash
pip install -r requirements-client.txt
```

**Or install all at once:**
```bash
pip install fastapi uvicorn python-multipart jinja2 websockets wsproto psutil pillow aiohttp
```

### Step 2: Configure Server Settings

Edit `server.py` and change these variables if needed:

```python
SERVER_NAME = "MyRenderRat v1.0"
SERVER_PORT = 8000
SERVER_HOST = "0.0.0.0"
SESSION_TIMEOUT = 1800  # 30 minutes
```

### Step 3: Configure Client Settings

Edit `client.py` and set the server address:

```python
SERVER_URL = "ws://your-server-ip:8000"  # Change to your server's address
CLIENT_ID = str(uuid.uuid4())[:12]
RECONNECT_INTERVAL = 5
```

---

## Configuration

### Credentials

Edit `auth.json` to change login credentials:

```json
{
  "admin": "MySecurePass@123",
  "user": "User@12345"
}
```

**⚠️ IMPORTANT:** Change default passwords before deployment!

### Environment Variables

Create a `.env` file from `.env.example`:

```bash
cp .env.example .env
```

Then edit `.env` with your settings.

---

## Running Server

### Option 1: Direct Python (Development)

```bash
# Windows
python server.py

# Linux/Mac
python3 server.py
```

### Option 2: Using Startup Scripts

**Windows:**
```bash
start-server.bat
```

**Linux/Mac:**
```bash
bash start-server.sh
```

### Option 3: Using Uvicorn

```bash
uvicorn server:app --host 0.0.0.0 --port 8000 --reload
```

### Verify Server is Running

- Open browser: `http://localhost:8000`
- You should see the login page
- Default credentials: `admin` / `MySecurePass@123`

---

## Running Client

### On the Target Machine

1. **Edit Server Address:**
   ```python
   # In client.py, line 25:
   SERVER_URL = "ws://server-ip-address:8000"
   ```

2. **Run Client:**
   ```bash
   # Windows
   python client.py

   # Linux/Mac
   python3 client.py
   ```

3. **Verify Connection:**
   - Check the console output for: `[CLIENT] Đã kết nối thành công!`
   - The client will attempt to reconnect automatically if disconnected

### Auto-Start on Boot (Optional)

**Windows (Task Scheduler):**
1. Open Task Scheduler
2. Create Basic Task
3. Trigger: At startup
4. Action: Start program `python client.py`

**Linux (systemd):**
1. Create `/etc/systemd/system/myrender-client.service`:
   ```ini
   [Unit]
   Description=MyRenderRat Client
   After=network.target

   [Service]
   Type=simple
   User=root
   WorkingDirectory=/path/to/myrender
   ExecStart=/usr/bin/python3 /path/to/myrender/client.py
   Restart=always
   RestartSec=10

   [Install]
   WantedBy=multi-user.target
   ```

2. Enable and start:
   ```bash
   sudo systemctl enable myrender-client
   sudo systemctl start myrender-client
   ```

---

## Web Interface

### Accessing the Admin Panel

1. Open browser: `http://server-ip:8000`
2. Login with credentials (default: `admin` / `MySecurePass@123`)
3. You should see connected clients in the dashboard

### Features Available

- 📸 **Screenshot**: Capture current screen
- 🎥 **Video Stream**: Live desktop streaming
- ⌨️ **Command Execution**: Run shell commands
- 📊 **System Info**: View hardware/OS details
- 🔄 **Process Manager**: View and kill processes
- 📁 **File Manager**: Browse, upload, download files

---

## Troubleshooting

### Server Won't Start

```bash
# Check if port is in use
# Windows:
netstat -ano | findstr :8000

# Linux/Mac:
lsof -i :8000

# Kill process using the port
# Windows:
taskkill /PID <PID> /F

# Linux/Mac:
kill -9 <PID>
```

### Client Won't Connect

1. **Check server is running:**
   ```bash
   # Test connection
   curl http://server-ip:8000
   ```

2. **Verify firewall:**
   - Allow port 8000 in firewall settings
   - Check Windows Firewall / UFW rules

3. **Check CLIENT_ID:**
   - Each client needs unique CLIENT_ID
   - Currently auto-generated, but ensure no conflicts

### Screenshot/Stream Not Working

1. **Install PIL properly:**
   ```bash
   pip install pillow --upgrade
   ```

2. **Windows - Install Visual C++:**
   - Download Microsoft C++ Build Tools
   - Pillow needs compilation

3. **Linux - Install dependencies:**
   ```bash
   sudo apt-get install python3-dev
   pip install pillow
   ```

### High Memory Usage

- Reduce `SCREENSHOT_QUALITY` in code (default: 85)
- Reduce `STREAM_QUALITY` (default: 75)
- Reduce `SCREENSHOT_MAX_WIDTH` and `HEIGHT`

### Performance Issues

1. **Server Side:**
   - Close unused client connections
   - Reduce session timeout in code
   - Disable video streaming if not needed

2. **Network:**
   - Ensure stable connection (ideally 100+ Mbps)
   - Use LAN instead of WAN if possible
   - Reduce video quality

---

## Security Recommendations

⚠️ **IMPORTANT:**

1. **Change Default Passwords:**
   - Edit `auth.json` immediately
   - Use strong passwords (16+ chars)

2. **Enable HTTPS/SSL:**
   - Generate self-signed certificate
   - Update server.py with SSL config
   - See `BUILD_STANDALONE.md`

3. **Restrict Access:**
   - Use VPN for remote access
   - Whitelist IP addresses
   - Implement rate limiting

4. **Network Security:**
   - Don't expose server to public internet
   - Use firewall rules
   - Monitor logs for suspicious activity

5. **Keep Updated:**
   - Update dependencies regularly: `pip install --upgrade -r requirements-server.txt`
   - Check for security patches

---

## Advanced Configuration

### Custom Port

Edit `server.py`:
```python
SERVER_PORT = 9999  # Custom port
```

### Multiple Instances

Run multiple server instances on different ports:
```bash
# Terminal 1
python server.py --port 8000

# Terminal 2
python server.py --port 8001
```

### Logging

Enable debug logging in `server.py`:
```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

---

## Support & Documentation

- 📖 See `README.md` for overview
- 🚀 See `QUICK_START.md` for quick setup
- 🏗️ See `BUILD_STANDALONE.md` for distribution
- 📝 See `CHANGELOG.md` for version history

---

**Last Updated:** April 2026
**Version:** 1.0
