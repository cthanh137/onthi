"""
MyRenderRat - Configuration Module
Cấu hình tập trung cho cả server và client
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Tải biến từ .env nếu tồn tại
load_dotenv()

# ===============================
# SERVER CONFIG
# ===============================

class ServerConfig:
    """Cấu hình Server"""
    
    # Thông tin server
    NAME = os.getenv("SERVER_NAME", "MyRenderRat v1.0")
    PORT = int(os.getenv("SERVER_PORT", 8000))
    HOST = os.getenv("SERVER_HOST", "0.0.0.0")
    DEBUG = os.getenv("DEBUG", "False").lower() == "true"
    
    # Security
    SESSION_TIMEOUT = int(os.getenv("SESSION_TIMEOUT", 1800))  # 30 phút
    SESSION_CLEANUP_INTERVAL = int(os.getenv("SESSION_CLEANUP_INTERVAL", 60))
    MAX_FAILED_LOGINS = int(os.getenv("MAX_FAILED_LOGINS", 5))
    
    # File paths
    AUTH_FILE = "auth.json"
    SESSION_FILE = "sessions.json"
    LOG_FILE = "server.log"
    
    # Features
    FEATURES = {
        "screenshot": os.getenv("ENABLE_SCREENSHOT", "True").lower() == "true",
        "video_stream": os.getenv("ENABLE_VIDEO_STREAM", "True").lower() == "true",
        "command_execution": os.getenv("ENABLE_COMMAND_EXECUTION", "True").lower() == "true",
        "file_management": os.getenv("ENABLE_FILE_MANAGEMENT", "True").lower() == "true",
        "audio": os.getenv("ENABLE_AUDIO", "True").lower() == "true",
    }
    
    # Limits
    MAX_FILE_SIZE_MB = int(os.getenv("MAX_FILE_SIZE_MB", 100))
    MAX_SCREENSHOT_QUALITY = int(os.getenv("MAX_SCREENSHOT_QUALITY", 95))
    MIN_SCREENSHOT_QUALITY = int(os.getenv("MIN_SCREENSHOT_QUALITY", 30))
    STREAM_FPS = int(os.getenv("STREAM_FPS", 20))
    STREAM_RESOLUTION = os.getenv("STREAM_RESOLUTION", "1280x720")
    
    # Logging
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
    ENABLE_FILE_LOGGING = os.getenv("ENABLE_FILE_LOGGING", "True").lower() == "true"

# ===============================
# CLIENT CONFIG
# ===============================

class ClientConfig:
    """Cấu hình Client"""
    
    # Server connection
    SERVER_URL = os.getenv("SERVER_URL", "ws://localhost:8000")
    RECONNECT_INTERVAL = int(os.getenv("CLIENT_RECONNECT_INTERVAL", 5))
    MAX_RETRIES = int(os.getenv("CLIENT_MAX_RETRIES", 999))
    
    # Features
    ENABLE_SCREENSHOT = os.getenv("ENABLE_SCREENSHOT", "True").lower() == "true"
    ENABLE_VIDEO_STREAM = os.getenv("ENABLE_VIDEO_STREAM", "True").lower() == "true"
    ENABLE_COMMAND = os.getenv("ENABLE_COMMAND_EXECUTION", "True").lower() == "true"
    ENABLE_FILE_MANAGER = os.getenv("ENABLE_FILE_MANAGEMENT", "True").lower() == "true"
    
    # Limits
    SCREENSHOT_QUALITY = 85
    STREAM_FPS = int(os.getenv("STREAM_FPS", 20))
    COMMAND_TIMEOUT = 30  # giây

# ===============================
# LOGGING CONFIG
# ===============================

LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "standard": {
            "format": "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
        },
        "detailed": {
            "format": "%(asctime)s [%(levelname)s] %(filename)s:%(lineno)d - %(funcName)s(): %(message)s"
        },
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "level": "INFO",
            "formatter": "standard",
            "stream": "ext://sys.stdout",
        },
        "file": {
            "class": "logging.FileHandler",
            "level": "DEBUG",
            "formatter": "detailed",
            "filename": ServerConfig.LOG_FILE,
        },
    },
    "root": {
        "level": "INFO",
        "handlers": ["console", "file"] if ServerConfig.ENABLE_FILE_LOGGING else ["console"],
    },
}

# ===============================
# DATABASE CONFIG (Optional)
# ===============================

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "sqlite:///./myrender.db"
)

# ===============================
# SECURITY HEADERS
# ===============================

SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "X-XSS-Protection": "1; mode=block",
    "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
}

# ===============================
# HELPER FUNCTIONS
# ===============================

def get_server_url():
    """Lấy URL server"""
    port = ServerConfig.PORT
    protocol = "https" if port == 443 else "http"
    return f"{protocol}://localhost:{port}"

def get_ws_server_url():
    """Lấy WebSocket URL server"""
    port = ServerConfig.PORT
    protocol = "wss" if port == 443 else "ws"
    return f"{protocol}://localhost:{port}"

def is_feature_enabled(feature_name: str) -> bool:
    """Kiểm tra tính năng có được bật không"""
    return ServerConfig.FEATURES.get(feature_name, True)

# ===============================
# EXAMPLES
# ===============================

if __name__ == "__main__":
    print("Server Config:")
    print(f"  Name: {ServerConfig.NAME}")
    print(f"  Host: {ServerConfig.HOST}")
    print(f"  Port: {ServerConfig.PORT}")
    print(f"  Debug: {ServerConfig.DEBUG}")
    print(f"  Features: {ServerConfig.FEATURES}")
    print()
    print("Client Config:")
    print(f"  Server URL: {ClientConfig.SERVER_URL}")
    print(f"  Reconnect Interval: {ClientConfig.RECONNECT_INTERVAL}s")
    print()
    print(f"Server URL: {get_server_url()}")
    print(f"WS URL: {get_ws_server_url()}")
