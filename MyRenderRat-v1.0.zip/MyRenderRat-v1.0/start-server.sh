#!/bin/bash
# MyRenderRat - Server Startup Script (Linux/Mac)

echo ""
echo "======================================================================"
echo "   MyRenderRat - Remote Access Tool"
echo "======================================================================"
echo ""

# Kiểm tra Python
if ! command -v python3 &> /dev/null; then
    echo "[ERROR] Python 3 not found!"
    echo "Please install Python 3:"
    echo "  Ubuntu/Debian: sudo apt install python3 python3-pip"
    echo "  macOS: brew install python3"
    exit 1
fi

echo "[OK] Python found: $(python3 --version)"
echo ""

# Tạo virtual environment (optional nhưng recommended)
if [ ! -d "venv" ]; then
    echo "[*] Creating virtual environment..."
    python3 -m venv venv
fi

echo "[*] Activating virtual environment..."
source venv/bin/activate

echo "[*] Installing dependencies..."
pip install -r requirements-server.txt

if [ $? -ne 0 ]; then
    echo "[ERROR] Failed to install dependencies"
    exit 1
fi

echo "[OK] Dependencies installed"
echo ""

# Kiểm tra files
if [ ! -f "auth.json" ]; then
    echo "[WARNING] auth.json not found, creating default..."
    cat > auth.json << 'EOF'
{
  "users": [
    {
      "username": "admin",
      "password": "MySecurePass@123"
    }
  ]
}
EOF
fi

if [ ! -f "sessions.json" ]; then
    echo '{"sessions": []}' > sessions.json
fi

echo ""
echo "======================================================================"
echo "   Starting MyRenderRat Server..."
echo "======================================================================"
echo ""
echo "Server sẽ chạy tại: http://localhost:8000"
echo "Login page: http://localhost:8000/login"
echo ""
echo "Nhấn Ctrl+C để dừng server"
echo ""

python3 server.py
