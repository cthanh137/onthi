@echo off
REM MyRenderRat - Server Startup Script (Windows)

echo.
echo ======================================================================
echo    MyRenderRat - Remote Access Tool
echo ======================================================================
echo.

REM Kiểm tra Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python 3 not found!
    echo Please install Python from https://www.python.org
    pause
    exit /b 1
)

echo [OK] Python found
echo.

REM Cài dependencies
echo [*] Installing dependencies...
pip install -r requirements-server.txt
if errorlevel 1 (
    echo [ERROR] Failed to install dependencies
    pause
    exit /b 1
)

echo [OK] Dependencies installed
echo.

REM Kiểm tra files
if not exist auth.json (
    echo [WARNING] auth.json not found, creating default...
    (
        echo {
        echo   "users": [
        echo     {
        echo       "username": "admin",
        echo       "password": "MySecurePass@123"
        echo     }
        echo   ]
        echo }
    ) > auth.json
)

if not exist sessions.json (
    echo {"sessions": []} > sessions.json
)

echo.
echo ======================================================================
echo    Starting MyRenderRat Server...
echo ======================================================================
echo.
echo Server akan chạy tại: http://localhost:8000
echo Login page: http://localhost:8000/login
echo.
echo Nhấn Ctrl+C để dừng server
echo.

python server.py

pause
