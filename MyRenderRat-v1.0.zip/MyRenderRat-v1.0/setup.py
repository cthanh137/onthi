"""
MyRenderRat - Setup Script
Để cài đặt package: pip install -e .
"""

from setuptools import setup, find_packages
from pathlib import Path

# Đọc README
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding="utf-8")

setup(
    name="MyRenderRat",
    version="1.0.0",
    author="MyRenderRat Team",
    author_email="info@myrender.local",
    description="Remote Access Tool - Control computers remotely",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/myrender-rat",
    license="MIT",
    
    # Packages
    packages=find_packages(),
    
    # Python version
    python_requires=">=3.8",
    
    # Dependencies
    install_requires=[
        # Server
        "fastapi>=0.104.1",
        "uvicorn[standard]>=0.24.0",
        "python-multipart>=0.0.6",
        "jinja2>=3.1.2",
        "websockets>=12.0",
        "wsproto>=1.1.0",
        
        # Client
        "websockets>=12.0",
        "psutil>=5.9.6",
        "pillow>=10.1.0",
        
        # Common
        "python-dotenv>=1.0.0",
    ],
    
    # Optional dependencies
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
            "mypy>=1.0.0",
        ],
        "docker": [
            "docker>=6.0.0",
        ],
        "database": [
            "sqlalchemy>=2.0.0",
            "psycopg2-binary>=2.9.0",  # PostgreSQL
        ],
    },
    
    # Entry points
    entry_points={
        "console_scripts": [
            "myrender-server=server:main",
            "myrender-client=client:main",
        ],
    },
    
    # Classifiers
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: System Administrators",
        "Intended Audience :: Information Technology",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: System :: Monitoring",
        "Topic :: System :: Networking",
    ],
    
    # Keywords
    keywords=[
        "remote-access",
        "remote-desktop",
        "system-administration",
        "monitoring",
        "websocket",
        "asyncio",
    ],
    
    # Project URLs
    project_urls={
        "Bug Reports": "https://github.com/yourusername/myrender-rat/issues",
        "Documentation": "https://github.com/yourusername/myrender-rat",
        "Source Code": "https://github.com/yourusername/myrender-rat",
    },
    
    # Include package data
    include_package_data=True,
    package_data={
        "": [
            "templates/*.html",
            "static/**/*",
            "*.json",
            "*.md",
        ],
    },
    
    # Metadata
    zip_safe=False,
)
