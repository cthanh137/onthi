"""
MyRenderRat - Connection Tester
Test kết nối giữa Server và Client
"""

import asyncio
import websockets
import json
import sys
from datetime import datetime

# ===============================
# TEST SERVER CONNECTION
# ===============================

async def test_server_connection(server_url="ws://localhost:8000/ws/admin"):
    """Test kết nối đến server"""
    print(f"\n🧪 Testing Server Connection")
    print("=" * 60)
    print(f"Server URL: {server_url}")
    print("-" * 60)
    
    try:
        async with websockets.connect(server_url, ping_interval=None) as websocket:
            print("✅ Connected to server!")
            
            # Test: Gửi message
            test_msg = {
                "type": "test",
                "timestamp": datetime.now().isoformat()
            }
            
            print(f"📤 Sending test message...")
            await websocket.send(json.dumps(test_msg))
            
            # Test: Nhận message
            print(f"📥 Waiting for response (5s timeout)...")
            try:
                response = await asyncio.wait_for(websocket.recv(), timeout=5.0)
                print(f"✅ Received response: {response[:100]}...")
            except asyncio.TimeoutError:
                print(f"⚠️  No response from server (timeout)")
            
            return True
    
    except ConnectionRefusedError:
        print("❌ Connection refused - Server not running?")
        return False
    except Exception as e:
        print(f"❌ Connection error: {e}")
        return False

# ===============================
# TEST CLIENT CONNECTION
# ===============================

async def test_client_connection(server_url="ws://localhost:8000", client_id="test-client-001"):
    """Test koneksi client"""
    print(f"\n🧪 Testing Client Connection")
    print("=" * 60)
    print(f"Server URL: {server_url}")
    print(f"Client ID: {client_id}")
    print("-" * 60)
    
    ws_url = f"{server_url}/ws/client/{client_id}"
    
    try:
        async with websockets.connect(ws_url, ping_interval=None) as websocket:
            print("✅ Client connected to server!")
            
            # Test: Server gửi request screenshot
            test_msg = {
                "type": "request_screenshot",
                "quality": 85
            }
            
            print(f"📤 Sending screenshot request...")
            await websocket.send(json.dumps(test_msg))
            
            print(f"⏳ Waiting for screenshot response (5s timeout)...")
            try:
                response = await asyncio.wait_for(websocket.recv(), timeout=5.0)
                data = json.loads(response)
                print(f"✅ Received response: type={data.get('type')}")
            except asyncio.TimeoutError:
                print(f"⚠️  No response (timeout) - expected if no admin is watching")
            
            return True
    
    except ConnectionRefusedError:
        print("❌ Connection refused - Server not running?")
        return False
    except Exception as e:
        print(f"❌ Connection error: {e}")
        return False

# ===============================
# TEST NETWORK
# ===============================

def test_network():
    """Test network & dependencies"""
    print(f"\n🧪 Testing Network & Dependencies")
    print("=" * 60)
    
    # Test: Python version
    import platform
    print(f"✅ Python: {platform.python_version()}")
    
    # Test: websockets
    try:
        import websockets
        print(f"✅ websockets: {websockets.__version__}")
    except ImportError:
        print(f"❌ websockets not installed: pip install websockets")
        return False
    
    # Test: fastapi (for server)
    try:
        import fastapi
        print(f"✅ fastapi: {fastapi.__version__}")
    except ImportError:
        print(f"⚠️  fastapi not installed (needed for server): pip install fastapi")
    
    # Test: uvicorn (for server)
    try:
        import uvicorn
        print(f"✅ uvicorn: {uvicorn.__version__}")
    except ImportError:
        print(f"⚠️  uvicorn not installed (needed for server): pip install uvicorn")
    
    # Test: psutil (for client)
    try:
        import psutil
        print(f"✅ psutil: {psutil.__version__}")
    except ImportError:
        print(f"⚠️  psutil not installed (needed for client): pip install psutil")
    
    # Test: PIL (for client screenshots)
    try:
        import PIL
        print(f"✅ Pillow (PIL): {PIL.__version__}")
    except ImportError:
        print(f"⚠️  Pillow not installed (needed for screenshots): pip install pillow")
    
    print("-" * 60)
    return True

# ===============================
# MAIN TEST MENU
# ===============================

async def main():
    print("\n" + "=" * 60)
    print("  MyRenderRat - Connection Tester")
    print("=" * 60)
    
    while True:
        print("\n📋 Select Test:")
        print("1️⃣  Test network & dependencies")
        print("2️⃣  Test admin connection (ws://localhost:8000/ws/admin)")
        print("3️⃣  Test client connection (ws://localhost:8000/ws/client/test)")
        print("4️⃣  Full test (1+2+3)")
        print("5️⃣  Custom server URL")
        print("0️⃣  Exit")
        
        choice = input("\nEnter choice (0-5): ").strip()
        
        if choice == "1":
            test_network()
        
        elif choice == "2":
            success = await test_server_connection()
            if success:
                print("\n✅ Admin connection test passed!")
            else:
                print("\n❌ Admin connection test failed!")
        
        elif choice == "3":
            success = await test_client_connection()
            if success:
                print("\n✅ Client connection test passed!")
            else:
                print("\n❌ Client connection test failed!")
        
        elif choice == "4":
            print("\n🔄 Running full test...")
            test_network()
            await test_server_connection()
            await test_client_connection()
            print("\n🎉 Full test completed!")
        
        elif choice == "5":
            server_url = input("Enter server URL (ws://IP:PORT): ").strip()
            await test_server_connection(f"{server_url}/ws/admin")
            await test_client_connection(server_url)
        
        elif choice == "0":
            print("\n👋 Goodbye!")
            sys.exit(0)
        
        else:
            print("❌ Invalid choice!")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n👋 Test interrupted by user")
        sys.exit(0)
