# Build MyRenderRat as Standalone Executable

## 🔧 PyInstaller Method (Recommended)

### 1. Cài Đặt PyInstaller
```bash
pip install pyinstaller
```

### 2. Build Server Executable

#### Windows:
```bash
# Single file executable
pyinstaller --onefile --windowed --name "MyRenderRat-Server" server.py

# Output: dist/MyRenderRat-Server.exe
```

#### Linux/Mac:
```bash
pyinstaller --onefile --name "MyRenderRat-Server" server.py

# Output: dist/MyRenderRat-Server
```

### 3. Build Client Executable

#### Windows:
```bash
pyinstaller --onefile --name "MyRenderRat-Client" client.py

# Output: dist/MyRenderRat-Client.exe
```

#### Linux/Mac:
```bash
pyinstaller --onefile --name "MyRenderRat-Client" client.py

# Output: dist/MyRenderRat-Client
```

---

## 📦 Tạo Installer (Advanced)

### Cho Windows (NSIS Installer):

1. Cài NSIS từ nsis.sourceforge.io
2. Tạo file `installer.nsi`:

```nsis
Name "MyRenderRat"
OutFile "MyRenderRat-Setup.exe"
InstallDir "$PROGRAMFILES\MyRenderRat"

Page directory
Page instfiles

Section "Install"
  SetOutPath "$INSTDIR"
  File "dist\MyRenderRat-Server.exe"
  File "dist\MyRenderRat-Client.exe"
  File "auth.json"
  File "README.md"
  
  CreateDirectory "$SMPROGRAMS\MyRenderRat"
  CreateShortCut "$SMPROGRAMS\MyRenderRat\Server.lnk" "$INSTDIR\MyRenderRat-Server.exe"
  CreateShortCut "$SMPROGRAMS\MyRenderRat\Client.lnk" "$INSTDIR\MyRenderRat-Client.exe"
SectionEnd
```

3. Build: `makensis installer.nsi`

---

## 🐳 Docker Method (Best for Production)

### 1. Tạo `Dockerfile`:

```dockerfile
FROM python:3.10-slim

WORKDIR /app

COPY requirements-server.txt .
RUN pip install --no-cache-dir -r requirements-server.txt

COPY . .

EXPOSE 8000

CMD ["python", "server.py"]
```

### 2. Build Docker Image:

```bash
docker build -t myrender-server:1.0 .
```

### 3. Run Container:

```bash
docker run -p 8000:8000 \
  -v $(pwd)/auth.json:/app/auth.json \
  -v $(pwd)/sessions.json:/app/sessions.json \
  myrender-server:1.0
```

### 4. Docker Compose (Recommended):

```yaml
# docker-compose.yml
version: '3.8'

services:
  server:
    build: .
    ports:
      - "8000:8000"
    volumes:
      - ./auth.json:/app/auth.json
      - ./sessions.json:/app/sessions.json
    environment:
      - SERVER_NAME=MyRenderRat v1.0
      - SERVER_PORT=8000
    restart: unless-stopped
```

```bash
# Run:
docker-compose up -d

# Stop:
docker-compose down
```

---

## 📊 Kích Thước File

| Method | Size |
|--------|------|
| Single Python Script | ~30KB |
| With Dependencies (venv) | ~200MB |
| PyInstaller (onefile) | ~80MB |
| Docker Image | ~400MB |

---

## 🚀 Distribution

### Option 1: GitHub Release
```bash
git init
git add .
git commit -m "MyRenderRat v1.0"
git tag v1.0
git push origin v1.0

# Tạo Release trên GitHub & upload exe
```

### Option 2: Self-Hosted
```bash
# Zip nó lại
zip -r MyRenderRat-v1.0.zip dist/ auth.json README.md

# Upload to server/cloud
```

---

## ✅ Checklist Trước Release

- [ ] Thay đổi mật khẩu mặc định
- [ ] Enable HTTPS/SSL
- [ ] Viết changelog
- [ ] Test trên Windows/Linux/Mac
- [ ] Cập nhật README
- [ ] Viết license
- [ ] Sign executable (Windows)

---

Good luck! 🚀
