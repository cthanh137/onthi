# MyRenderRat - Project Structure

Cấu trúc chi tiết của dự án:

```
MyRenderRat/
│
├── 📄 Core Files
│   ├── server.py                 # Server chính (FastAPI + WebSocket)
│   ├── client.py                 # Client chính (AsyncIO + WebSocket)
│   └── config.py                 # Cấu hình tập trung
│
├── 📄 Configuration
│   ├── auth.json                 # Danh sách tài khoản (username/password)
│   ├── sessions.json             # Quản lý phiên đang hoạt động
│   ├── .env.example              # Ví dụ biến môi trường
│   └── .gitignore                # Exclude files từ Git
│
├── 📚 Documentation
│   ├── README.md                 # Hướng dẫn đầy đủ
│   ├── QUICK_START.md            # Khởi động nhanh (5 phút)
│   ├── BUILD_STANDALONE.md       # Hướng dẫn build executable
│   ├── PROJECT_STRUCTURE.md      # File này
│   ├── CHANGELOG.md              # Lịch sử thay đổi
│   └── LICENSE                   # MIT License
│
├── 🎨 Web Interface
│   ├── templates/
│   │   ├── login.html            # Trang đăng nhập (responsive design)
│   │   └── admin.html            # Bảng điều khiển admin
│   └── static/
│       ├── css/                  # Stylesheets (nếu có)
│       ├── js/                   # JavaScript files (nếu có)
│       └── img/                  # Images (nếu có)
│
├── 📦 Dependencies
│   ├── requirements-server.txt   # Thư viện cho server
│   ├── requirements-client.txt   # Thư viện cho client
│   └── setup.py                  # Package setup file
│
├── 🚀 Scripts
│   ├── start-server.bat          # Start server (Windows)
│   ├── start-server.sh           # Start server (Linux/Mac)
│   ├── test.py                   # Test connection
│   └── build-docker.sh           # Build Docker image
│
└── 📁 Directories (được tạo khi chạy)
    ├── venv/                     # Virtual environment
    ├── dist/                     # Build output (PyInstaller)
    ├── __pycache__/              # Python cache
    └── logs/                     # Log files
```

---

## 📄 Chi Tiết Từng File

### Core Files

#### `server.py` (~500 lines)
```python
# Chức năng chính:
- FastAPI application setup
- WebSocket endpoints (/ws/admin, /ws/client/{id})
- Authentication (login, logout)
- Message routing (Admin ↔ Client)
- File transfer handling
- Session management
- Startup events
```

**Endpoints chính:**
- `GET /login` → Trang đăng nhập
- `POST /login` → Xử lý đăng nhập
- `GET /logout` → Đăng xuất
- `GET /` → Bảng điều khiển admin
- `WS /ws/admin` → WebSocket cho admin
- `WS /ws/client/{id}` → WebSocket cho client

#### `client.py` (~400 lines)
```python
# Chức năng chính:
- WebSocket client connection
- System information gathering
- Screenshot capture
- Command execution
- Process management
- File operations
- Message handling
- Auto-reconnect logic
```

**Handlers:**
- `request_screenshot` → Chụp màn hình
- `request_sysinfo` → Thông tin hệ thống
- `request_processes` → Danh sách tiến trình
- `command` → Thực thi lệnh
- `start_stream` / `stop_stream` → Video stream
- `list_directory` → Duyệt thư mục
- `read_file` → Đọc tập tin

#### `config.py` (~150 lines)
```python
# Cấu hình tập trung:
class ServerConfig
  - PORT, HOST, DEBUG
  - SESSION_TIMEOUT
  - FEATURES (enable/disable)
  - LIMITS (file size, quality, etc)

class ClientConfig
  - SERVER_URL
  - RECONNECT_INTERVAL
  - FEATURES
```

### Configuration Files

#### `auth.json`
```json
{
  "users": [
    {
      "username": "admin",
      "password": "secure_password_123"
    }
  ]
}
```
- Format: JSON
- Được load khi server start
- Thay đổi = restart server

#### `sessions.json`
```json
{
  "sessions": [
    {
      "username": "admin",
      "ip": "192.168.1.100",
      "expires": "2025-04-06T10:30:00",
      "login_time": "2025-04-06T10:00:00"
    }
  ]
}
```
- Tự động tạo/cập nhật
- Dọn dẹp expired sessions mỗi phút
- Không nên edit trực tiếp

### Templates

#### `templates/login.html` (~200 lines)
- Modern gradient design
- Form validation (client-side)
- Responsive (mobile-friendly)
- Error messages
- Demo credentials display

#### `templates/admin.html` (~400 lines)
- Sidebar với client list
- Multiple control panels
- Real-time updates via WebSocket
- Screenshot viewer
- Command terminal
- System info display

### Scripts

#### `start-server.bat` (Windows)
```batch
@echo off
python --version
pip install -r requirements-server.txt
python server.py
```

#### `start-server.sh` (Linux/Mac)
```bash
#!/bin/bash
python3 --version
python3 -m venv venv
source venv/bin/activate
pip install -r requirements-server.txt
python3 server.py
```

#### `test.py`
- Menu-driven testing
- Test network & dependencies
- Test admin connection
- Test client connection
- Custom server URL testing

---

## 🔄 Data Flow

### Connection Flow
```
┌─────────────┐                    ┌──────────────┐
│   Browser   │ ─── HTTP GET ────> │              │
│  (Admin)    │ <─── HTML ────────  │              │
│             │                     │   FastAPI    │
│             │ ─── WS /ws/admin ─> │   Server     │
│             │ <─ WebSocket ──────  │              │
└─────────────┘                    └──────────────┘
                                         ▲
                                         │ WS
                                         │
                                   ┌─────▼──────┐
                                   │   Client   │
                                   │ (Remote    │
                                   │  Machine)  │
                                   └────────────┘
```

### Message Flow
```
Admin                Server               Client
  │                    │                    │
  ├─ request_screenshot──>                 │
  │                    ├──request_screenshot──>
  │                    │                   ├─ capture
  │                    │                   │
  │                    │<──screenshot data──┤
  │                    │                    │
  │<──screenshot data───┤                   │
  │                    │                    │
```

---

## 🔐 Security Flow

```
1. Admin akses http://localhost:8000/login
   ↓
2. Input username + password
   ↓
3. Server verify credentials vs auth.json
   ↓
4. Create session → sessions.json
   ↓
5. Redirect ke /admin
   ↓
6. Browser connect WebSocket /ws/admin
   ↓
7. Server allow connection (session valid)
   ↓
8. Admin dashboard active
```

---

## 📊 Database Schema (JSON)

### auth.json
```
users: [
  {
    username: string
    password: string
  }
]
```

### sessions.json
```
sessions: [
  {
    username: string
    ip: string (IPv4/IPv6)
    expires: ISO timestamp
    login_time: ISO timestamp
  }
]
```

---

## 🎯 File Size Guide

```
server.py              ~30 KB
client.py              ~25 KB
config.py              ~8 KB
auth.json              <1 KB
templates/login.html   ~10 KB
templates/admin.html   ~25 KB
requirements.txt       <1 KB
Total (code)           ~100 KB
Total (with deps)      ~200 MB (venv)
PyInstaller dist       ~80 MB
```

---

## 📋 Import Dependencies

### server.py imports:
```python
# FastAPI ecosystem
from fastapi import FastAPI, WebSocket, Request, HTTPException
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles

# Python stdlib
import json, os, asyncio
from datetime import datetime, timedelta
from typing import Dict, Set

# Third-party
import websockets  # (indirect via fastapi)
```

### client.py imports:
```python
# Async
import asyncio, websockets, json, threading

# System info
import psutil, platform, subprocess, os

# Screenshot
from PIL import ImageGrab

# Utilities
import uuid, base64, sys, time
```

---

## 🔧 Configuration Hierarchy

```
Default (hardcoded)
    ↓
.env.example (if exists)
    ↓
Environment Variables
    ↓
config.py classes (ServerConfig, ClientConfig)
```

---

## 📱 Responsive Design Breakpoints

Dari `templates/admin.html`:
```css
Desktop:  > 1200px (3-column layout)
Tablet:   768px - 1200px (2-column)
Mobile:   < 768px (1-column, stacked)
```

---

## 🚀 Build Pipeline

```
Source Code (server.py, client.py)
    ↓
PyInstaller
    ↓
Standalone Executables
    ├── MyRenderRat-Server.exe (Windows)
    ├── MyRenderRat-Server (Linux/Mac)
    ├── MyRenderRat-Client.exe (Windows)
    └── MyRenderRat-Client (Linux/Mac)
    ↓
Package (ZIP/Installer)
    ↓
Distribution (GitHub, Website, etc)
```

---

## 📝 Code Style

```python
# Naming convention
variables: snake_case
functions: snake_case()
Classes: PascalCase
CONSTANTS: UPPER_SNAKE_CASE

# Type hints (optional but recommended)
async def handle_message(message: dict) -> None: ...

# Docstrings
def my_function():
    """Short description"""
    return result
```

---

## 🧪 Testing Coverage

Dari `test.py`:
- Network diagnostics
- Dependency check
- Connection testing (admin & client)
- Message validation

---

## 📚 Documentation Structure

```
README.md (Overview + Full Guide)
├── Giới Thiệu
├── Cài Đặt & Setup
├── Sử Dụng
├── Tùy Chỉnh
├── Bảo Mật
├── Troubleshooting
└── Mở Rộng

QUICK_START.md (5-minute setup)
├── Server Setup
├── Web Access
├── Client Setup
├── Usage Examples
└── Troubleshooting

BUILD_STANDALONE.md (Compilation)
├── PyInstaller
├── NSIS Installer
├── Docker
└── Distribution
```

---

## 🔄 Update & Maintenance

```
1. Backup: auth.json, sessions.json
2. Git pull latest changes
3. pip install -r requirements.txt -U
4. Restart server
5. Test connection
```

---

**Version**: 1.0.0  
**Last Updated**: April 6, 2025  
**Total Files**: 20+  
**Total Lines of Code**: ~1500  
**Documentation Lines**: ~2000
