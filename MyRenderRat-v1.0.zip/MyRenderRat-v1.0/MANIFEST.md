# MyRenderRat v1.0 - File Manifest

## Package Contents

### 📂 Root Files

**Core Application Files:**
- `server.py` - FastAPI server (main application)
- `client.py` - Client daemon (runs on target machines)
- `config.py` - Configuration utilities
- `setup.py` - Python package setup script

**Testing:**
- `test.py` - Unit tests for components

**Configuration Files:**
- `.env` - Environment configuration (actual values)
- `.env.example` - Environment configuration template
- `auth.json` - User credentials (⚠️ change passwords!)
- `sessions.json` - Active session storage (auto-generated)

**Dependencies:**
- `requirements-server.txt` - Python packages for server
- `requirements-client.txt` - Python packages for client

**Startup Scripts:**
- `start-server.bat` - Windows server startup script
- `start-server.sh` - Linux/Mac server startup script (executable)

### 📄 Documentation Files

**Getting Started:**
- `README.md` - Comprehensive project overview
- `QUICK_START.md` - 5-minute setup guide
- `INSTALLATION.md` - Detailed installation & configuration guide

**Technical Documentation:**
- `PROJECT_STRUCTURE.md` - Project architecture & design
- `BUILD_STANDALONE.md` - Building executables & deployment
- `CHANGELOG.md` - Version history & updates

**Legal:**
- `LICENSE` - MIT License with usage terms
- `MANIFEST` - This file (package contents)

### 📁 templates/ - HTML Templates

Web interface files:
- `login.html` - Login page (Vietnamese UI)
- `admin.html` - Admin dashboard with all controls

### 📊 Statistics

- **Total Files:** 24
- **Python Files:** 4 (server, client, config, setup, test)
- **Documentation:** 6 markdown files
- **Configuration:** 4 JSON/env files
- **Scripts:** 2 (batch & shell)
- **HTML Templates:** 2
- **Package Size:** ~200KB (without dependencies)

---

## 🚀 Quick Start Paths

### Path 1: Immediate Setup (5 minutes)
1. Read `QUICK_START.md`
2. Install requirements: `pip install -r requirements-server.txt`
3. Run: `python server.py`
4. Access: http://localhost:8000

### Path 2: Full Setup (30 minutes)
1. Read `INSTALLATION.md`
2. Configure credentials in `auth.json`
3. Update `client.py` with server address
4. Run server and client
5. Test in web interface

### Path 3: Production Deployment (1-2 hours)
1. Read `BUILD_STANDALONE.md`
2. Follow PyInstaller or Docker instructions
3. Configure SSL/HTTPS
4. Deploy to production environment
5. Monitor with logging

---

## 📋 File Dependencies

### Server Dependencies
```
server.py
├── fastapi
├── uvicorn
├── websockets
├── jinja2
├── python-multipart
├── config.py
└── templates/
    ├── login.html
    └── admin.html
```

### Client Dependencies
```
client.py
├── websockets
├── psutil
├── pillow
└── aiohttp
```

### Configuration
```
auth.json
sessions.json
.env (optional)
```

---

## 🔐 Important Files (Protect These)

⚠️ **These files contain sensitive information:**
- `auth.json` - User passwords (CHANGE DEFAULT!)
- `sessions.json` - Active session tokens
- `.env` - Configuration with potential secrets

**Never commit these to public repositories!**

---

## 📝 File Descriptions

### server.py (16 KB)
Main FastAPI application
- WebSocket server for admin and client communication
- User authentication
- Session management
- File transfer endpoints
- Command routing

### client.py (14 KB)
Client daemon application
- Connects to server via WebSocket
- Captures screenshots
- Executes commands
- Manages processes
- Handles file operations

### config.py (5.4 KB)
Configuration management
- Settings classes
- Environment variable loading
- Default values
- Validation

### setup.py (3.1 KB)
Python package installation
- Entry points
- Package metadata
- Installation helpers

### test.py (6.6 KB)
Unit tests
- Component testing
- Configuration validation
- Utility function tests

### Templates

**login.html (5.5 KB)**
- Login interface
- Vietnamese language UI
- Gradient purple theme
- Form validation

**admin.html (16 KB)**
- Admin dashboard
- Client control panels
- Screenshot viewer
- Command executor
- Process manager
- File browser
- System info display
- Real-time updates via WebSocket

---

## 🔄 Workflow

### Server Startup
1. Load configuration from `.env` or defaults
2. Read `auth.json` for credentials
3. Initialize session storage (creates if missing)
4. Start FastAPI server on configured port
5. Listen for WebSocket connections

### Client Startup
1. Generate unique CLIENT_ID
2. Attempt connection to server
3. Upon connection, register as available
4. Listen for commands from admin
5. Auto-reconnect if disconnected

### Admin Usage
1. Navigate to server address
2. Login with credentials
3. Select client from list
4. Send commands/requests
5. Receive and display responses

---

## 🛠️ Customization Points

Files you'll likely want to modify:

1. **branding:** `server.py` (SERVER_NAME variable)
2. **passwords:** `auth.json` (credentials)
3. **port/host:** `server.py` (SERVER_PORT, SERVER_HOST)
4. **UI colors:** `templates/login.html` and `admin.html`
5. **features:** Enable/disable in `server.py` and `client.py`
6. **timeouts:** Session timeout in `server.py`

---

## 📦 Distribution

### As ZIP Archive
- Compress entire folder: `MyRenderRat-v1.0.zip`
- Share via secure channel
- Extract and follow QUICK_START.md

### As Python Package
- Use `setup.py` for installation
- `pip install -e .` for development
- `pip install .` for production

### As Standalone Executable
- See `BUILD_STANDALONE.md` for PyInstaller instructions
- Creates single .exe file (Windows) or binary (Linux)
- No Python installation needed on target

### As Docker Container
- See `BUILD_STANDALONE.md` for Dockerfile
- Run in containerized environment
- Portable across systems

---

## ✅ Pre-Deployment Checklist

Before sharing/deploying:

- [ ] Change default passwords in `auth.json`
- [ ] Update server address in `client.py`
- [ ] Configure SSL/HTTPS (see BUILD_STANDALONE.md)
- [ ] Test all features locally
- [ ] Review all template HTML files
- [ ] Update README with your info
- [ ] Test on target OS (Windows/Linux/Mac)
- [ ] Verify firewall rules
- [ ] Document any customizations

---

**Version:** 1.0
**Last Updated:** April 6, 2026
**Author:** MyRenderRat Contributors
**License:** MIT

For questions or support, refer to individual documentation files.
