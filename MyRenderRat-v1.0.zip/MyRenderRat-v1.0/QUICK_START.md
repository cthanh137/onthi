# 🚀 MyRenderRat - Quick Start Guide

## 1️⃣ Trên Máy QUẢN LÝ (Server)

### Windows:
```bash
# Bước 1: Mở Command Prompt
# Bước 2: Chuyển đến thư mục MyRenderRat
cd C:\path\to\MyRenderRat

# Bước 3: Chạy script
start-server.bat
```

### Linux/Mac:
```bash
# Bước 1: Mở Terminal
# Bước 2: Chuyển đến thư mục
cd /path/to/MyRenderRat

# Bước 3: Chạy script
bash start-server.sh
```

**Output sẽ hiển thị:**
```
============================================================
  MyRenderRat v1.0 đã khởi động!
============================================================
  Trang quản lý: http://localhost:8000
  Đăng nhập: http://localhost:8000/login
============================================================
```

✅ **Server đang chạy!**

---

## 2️⃣ Truy Cập Web Dashboard

### Mở Browser:
- URL: `http://localhost:8000/login`
- Username: `admin`
- Password: `MySecurePass@123`

✅ **Bạn đã đăng nhập!**

---

## 3️⃣ Trên Máy ĐƯỢC KIỂM SOÁT (Client)

### Windows:
```bash
# Cài dependencies
pip install -r requirements-client.txt

# Chạy client
python client.py
```

### Linux/Mac:
```bash
# Cài dependencies
pip3 install -r requirements-client.txt

# Chạy client
python3 client.py
```

**Output:**
```
============================================================
  MyRenderRat Client v1.0
============================================================
  Client ID: a1b2c3d4e5f6
  Server: ws://192.168.1.100:8000
  OS: Windows 10
============================================================
[CLIENT] Đã kết nối thành công!
```

✅ **Client đã kết nối!**

---

## 4️⃣ Kiểm Soát Client Từ Dashboard

1. **Chụp Screenshot**: Click "Chụp" → Xem ảnh màn hình
2. **Stream Video**: Click "Bắt Đầu Stream" → Xem real-time
3. **Thực Thi Lệnh**: Nhập lệnh → Click "Thực Thi" → Xem kết quả
4. **Thông Tin Hệ Thống**: Click "Lấy Thông Tin" → CPU, RAM, Disk
5. **Quản Lý Tập Tin**: Nhập đường dẫn → Browse file

---

## ⚙️ Tùy Chỉnh Cơ Bản

### Thay Đổi Port Server

**server.py:**
```python
SERVER_PORT = 9000  # Thay vì 8000
```

Sau đó server sẽ chạy tại `http://localhost:9000`

### Thay Đổi IP Server (Để Client Kết Nối)

**client.py:**
```python
SERVER_URL = "ws://192.168.1.100:8000"  # Thay IP của server
```

> 💡 Để tìm IP server: 
> - Windows: `ipconfig`
> - Linux/Mac: `ifconfig` hoặc `ip addr`

### Thay Đổi Mật Khẩu Đăng Nhập

**auth.json:**
```json
{
  "users": [
    {
      "username": "admin",
      "password": "YourNewPassword@123"
    }
  ]
}
```

---

## 🔍 Khắc Phục Sự Cố

### ❌ Client không kết nối được
```
✅ Kiểm tra:
1. Server đang chạy? (xem console)
2. IP server đúng không? (ipconfig)
3. Firewall cho phép port 8000?
4. Network: Server & Client cùng LAN?
```

### ❌ Port 8000 đang sử dụng
```bash
# Tìm process sử dụng port
lsof -i :8000 (Linux/Mac)
netstat -ano | findstr :8000 (Windows)

# Kill process
kill -9 <PID> (Linux/Mac)
taskkill /PID <PID> /F (Windows)

# Hoặc thay port khác trong server.py
SERVER_PORT = 8001
```

### ❌ Screenshot không hoạt động
```bash
# Cài Pillow
pip install pillow

# Thử lại
python client.py
```

### ❌ Client disconnect liên tục
```
✅ Nguyên nhân & giải pháp:
1. Network không ổn định → Kiểm tra kết nối Internet
2. Server restart → Kiểm tra logs server
3. Timeout → Tăng SESSION_TIMEOUT trong server.py
```

---

## 📊 Ví Dụ Sử Dụng

### 1️⃣ Lấy Thông Tin Máy
1. Login vào dashboard
2. Chọn client từ danh sách
3. Click "Lấy Thông Tin" → Xem CPU, RAM, OS

### 2️⃣ Chạy Lệnh Shell
1. Nhập lệnh: `dir` (Windows) hoặc `ls` (Linux)
2. Click "Thực Thi"
3. Xem output trong terminal

### 3️⃣ Xem Màn Hình Real-Time
1. Click "Bắt Đầu Stream"
2. Màn hình client sẽ tải lên
3. Click "Dừng Stream" để dừng

---

## 🌐 Sử Dụng Từ Internet (Advanced)

### Cách 1: Sử Dụng ngrok (Dễ Nhất)

```bash
# Cài ngrok: https://ngrok.com

# Expose server
ngrok tcp 8000
```

Output:
```
Forwarding tcp://0.tcp.ngrok.io:12345 -> localhost:8000
```

**client.py:**
```python
SERVER_URL = "ws://0.tcp.ngrok.io:12345"
```

### Cách 2: Domain + VPS

1. Thuê VPS (DigitalOcean, Linode, etc)
2. Upload code & chạy server
3. Setup domain DNS
4. Enable HTTPS (SSL certificate)
5. Update CLIENT_URL trong client.py

---

## 📱 Một Số Lệnh Hữu Ích

### Windows:
```
ipconfig                    # Xem IP
tasklist                    # Danh sách process
dir C:\Users              # Duyệt thư mục
systeminfo                # Thông tin hệ thống
shutdown /s /t 30         # Tắt máy sau 30s
taskkill /IM notepad.exe /F  # Kill process
```

### Linux/Mac:
```
ifconfig                  # Xem IP
ps aux                    # Danh sách process
ls -la                    # Duyệt thư mục
uname -a                  # Thông tin hệ thống
shutdown -h +5            # Tắt máy sau 5p
kill -9 <PID>             # Kill process
```

---

## ⚠️ Cảnh Báo Bảo Mật

🔴 **KHÔNG CÓ HTTPS?** → Dữ liệu có thể bị bắt sóng

✅ **PHẢI CÓ HTTPS** khi:
- Server trên Internet
- Chứa thông tin nhạy cảm
- Production environment

---

## 📞 Liên Hệ & Hỗ Trợ

- 📖 **Docs**: Xem README.md
- 🐛 **Bug Report**: Kiểm tra logs

```bash
# Xem server logs
tail -f /var/log/myrender.log (Linux)

# Xem client logs
python client.py  # Logs sẽ in ra console
```

---

## 🎉 Tóm Lại

```
1. Server start  → python server.py
2. Login        → http://localhost:8000/login
3. Client start → python client.py (trên máy khác)
4. Control      → Từ dashboard
5. Enjoy!       → 🎮
```

**Happy Remote Managing!** 🚀
